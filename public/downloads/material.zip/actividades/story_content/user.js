function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5z3JVdR2qBr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

